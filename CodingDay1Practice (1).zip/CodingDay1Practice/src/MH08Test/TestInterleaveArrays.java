package MH08Test;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import MH08.MH08;


public class TestInterleaveArrays {


	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


	@Test
	public void testInterleaveArrays1() {
		int[] a = {1,2,3};
		int[] b = {-1,-2,-3};
		int[] ab = {1,-1,2,-2,3,-3};
		assertArrayEquals(ab, MH08.interleaveArrays(a, b));
	}
	
	@Test
	public void testInterleaveArrays2() {
		int[] x = {-3,9};
		int[] y = {100,-100};
		int[] xy = {-3,100,9,-100};
		assertArrayEquals(xy, MH08.interleaveArrays(x, y));
	}
}