package MH08Test;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;

import MH08.MH08;


public class TestFindPair {
	
	
	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	@Test
	public void testFindPair() {
		int inputTarget = 8;
		int[] inputArray = {2, 10, 1, 5, 7, 4};
		int[] expectedResult = {1, 7};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}
	
	@Test
	public void testFindPair_0() {
		int inputTarget = 11;
		int[] inputArray = {9, 17, -5, 21, -10};
		int[] expectedResult = {-10, 21};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}
	
	@Test
	public void testFindPair_1() {
		int inputTarget = 5;
		int[] inputArray = {8, 12, 16, 20};
		int[] expectedResult = {};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}
	
	@Test
	public void testFindPair_2() {
		int inputTarget = 0;
		int[] inputArray = {11, -8, 47, 19, 100, -38, -47};
		int[] expectedResult = {-47, 47};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}
	
	@Test
	public void testFindPair_3() {
		int inputTarget = 7;
		int[] inputArray = {};
		int[] expectedResult = {};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}
	
	@Test
	public void testFindPair_4() {
		int inputTarget = 23;
		int[] inputArray = {23};
		int[] expectedResult = {};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}

	@Test
	public void testFindPair_5() {
		int inputTarget = 30;
		int[] inputArray = {-2, 15, -10, 24, 19, -3, 11};
		int[] expectedResult = {11, 19};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}
	
	@Test
	public void testFindPair_6() {
		int inputTarget = 30;
		int[] inputArray = {6, -5, 15, 28, -7, -4, 15, 12};
		int[] expectedResult = {15, 15};
		
		int[] actualResult = MH08.findPair(inputTarget, inputArray);
		assertArrayEquals(expectedResult, actualResult);
	}
}
