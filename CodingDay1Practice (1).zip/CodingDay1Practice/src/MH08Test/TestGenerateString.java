package MH08Test;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import MH08.MH08;

public class TestGenerateString {


	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	
	@Test
	public void testGenerateStringAllPositiveHALFCREDIT() {
		
		//Start with all positive values for the first half of the credit
		int[] numbers = {1, 1, 1, 1, 1};
		String[] inputStrs = {"a", "b", "c", "d", "e"};
		String expectedResult = "abcde";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {2, 2, 2, 2, 2};
		expectedResult = "aabbccddee";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {3, 3, 3, 3, 3};
		expectedResult = "aaabbbcccdddeee";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		
		numbers = new int[] {1, 2, 3, 2, 3};
		expectedResult = "abbcccddeee";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		
		numbers = new int[] {1, 1, 1, 1, 1};
		inputStrs = new String[] {"ab", "cd", "ef", "gh", "ij"};
		expectedResult = "abcdefghij";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {2, 2, 2, 2, 2};
		inputStrs = new String[] {"ab", "cd", "ef", "gh", "ij"};
		expectedResult = "ababcdcdefefghghijij";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {3, 3, 3, 3, 3};
		inputStrs = new String[] {"ab", "cd", "ef", "gh", "ij"};
		expectedResult = "abababcdcdcdefefefghghghijijij";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {1, 2, 3, 2, 3};
		inputStrs = new String[] {"ab", "cd", "ef", "gh", "ij"};
		expectedResult = "abcdcdefefefghghijijij";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		
		//Big positive value test
		numbers = new int[100];
		inputStrs = new String[100];
		expectedResult = "";
		int firstAsciiLetter = 97; //ASCII value of letter 'a'
		int lastAsciiLetter = 122; //ASCII value of letter 'z'
		for (int i = 0; i < 100; i++) { //make a 200 character string that contains all lower-case letters
			char tempChar1 = (char) ((i%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			char tempChar2 = (char) ((i+1%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			inputStrs[i] = "" + tempChar1 + "" + tempChar2;
			numbers[i] = i+1;
			for(int j = 0; j < i+1; j++) {
				expectedResult += inputStrs[i];
			}
		}
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
	}
	
	@Test
	public void testGenerateStringAllNegative() {
		int[] numbers = {-1, -1, -1, -1, -1};
		String[] inputStrs = {"a", "b", "c", "d", "e"};
		String expectedResult = "ABCDE";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-2, -2, -2, -2, -2};
		expectedResult = "AABBCCDDEE";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-3, -3, -3, -3, -3};
		expectedResult = "AAABBBCCCDDDEEE";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-1, -2, -3, -2, -3};
		expectedResult = "ABBCCCDDEEE";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-1, -1, -1, -1, -1};
		inputStrs = new String[] {"ab", "cd", "ef", "gh", "ij"};
		expectedResult = "BADCFEHGJI";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-2, -2, -2, -2, -2};
		expectedResult = "BABADCDCFEFEHGHGJIJI";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-3, -3, -3, -3, -3};
		expectedResult = "BABABADCDCDCFEFEFEHGHGHGJIJIJI";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-1, -2, -3, -2, -3};
		expectedResult = "BADCDCFEFEFEHGHGJIJIJI";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[100];
		inputStrs = new String[100];
		expectedResult = "";
		String curReverse;
		int firstAsciiLetter = 97; //ASCII value of letter 'a'
		int lastAsciiLetter = 122; //ASCII value of letter 'z'
		for (int i = 0; i < 100; i++) { //make a 200 character string that contains all lower-case letters
			char tempChar1 = (char) ((i%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			char tempChar2 = (char) ((i+1%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			inputStrs[i] = "" + tempChar1 + "" + tempChar2;
			curReverse = "" + tempChar2 + "" + tempChar1;
			curReverse = curReverse.toUpperCase();
			numbers[i] = -(i+1);
			for(int j = 0; j < i+1; j++) {
				expectedResult += curReverse;
			}
		}
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
	}
	
	@Test
	public void testGenerateStringMixedFULLCREDIT() {
		int[] numbers = {-1, 1, 1, -1, -1};
		String[] inputStrs = {"a", "b", "c", "d", "e"};
		String expectedResult = "AbcDE";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-2, -2, 2, 2, -2};
		expectedResult = "AABBccddEE";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {3, -3, -3, -3, 3};
		expectedResult = "aaaBBBCCCDDDeee";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-1, 2, 3, -2, -3};
		expectedResult = "AbbcccDDEEE";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-1, 1, -1, -1, 1};
		inputStrs = new String[] {"ab", "cd", "ef", "gh", "ij"};
		expectedResult = "BAcdFEHGij";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-2, -2, -2, 2, 2};
		expectedResult = "BABADCDCFEFEghghijij";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {3, -3, 3, -3, -3};
		expectedResult = "abababDCDCDCefefefHGHGHGJIJIJI";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[] {-1, 2, 3, -2, -3};
		expectedResult = "BAcdcdefefefHGHGJIJIJI";
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
		
		numbers = new int[100];
		inputStrs = new String[100];
		expectedResult = "";
		String curReverse;
		int firstAsciiLetter = 97; //ASCII value of letter 'a'
		int lastAsciiLetter = 122; //ASCII value of letter 'z'
		for (int i = 0; i < 100; i++) { //make a 200 character string that contains all lower-case letters
			char tempChar1 = (char) ((i%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			char tempChar2 = (char) ((i+1%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			inputStrs[i] = "" + tempChar1 + "" + tempChar2;
			
			if(i%2 == 0) {
				numbers[i] = i+1;
				for(int j = 0; j < i+1; j++) {
					expectedResult += inputStrs[i];
				}
			} else {
				curReverse = "" + tempChar2 + "" + tempChar1;
				curReverse = curReverse.toUpperCase();
				numbers[i] = -(i+1);
				for(int j = 0; j < i+1; j++) {
					expectedResult += curReverse;
				}
			}
		}
		assertEquals(expectedResult, MH08.generateString(numbers, inputStrs));
	}
}