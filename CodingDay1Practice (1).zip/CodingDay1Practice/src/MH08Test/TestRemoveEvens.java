package MH08Test;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;

import MH08.MH08;

public class TestRemoveEvens {

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	
	@Test
	public void testRemoveEvensN01() {
		Integer[] inputArray = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		Integer[] expectedArray = {1, 3, 5, 7 ,9};
		ArrayList<Integer> input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		ArrayList<Integer> expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN01
	
	@Test
	public void testRemoveEvensN02() {
		Integer[] inputArray = new Integer[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
		Integer[] expectedArray = {1, 3, 5, 7 ,9};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		ArrayList<Integer> expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		MH08.removeEvens(input);
		assertEquals(expected, input);
	} // testRemoveEvensN02
	
	@Test
	public void testRemoveEvensN03() {
		Integer[] inputArray = new Integer[] {2, 3, 4, 5, 6, 7, 8, 9, 0, 1};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		Integer[] expectedArray = new Integer[] {3, 5, 7 ,9, 1};
		ArrayList<Integer>expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN03
	
	@Test
	public void testRemoveEvensN04() {
		Integer[] inputArray = new Integer[] {3, 4, 5, 6, 7, 8, 9, 0, 1, 2};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		Integer[] expectedArray = new Integer[] {3, 5, 7 ,9, 1};
		ArrayList<Integer>expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN04
	
	@Test
	public void testRemoveEvensN05() {
		Integer[] inputArray = new Integer[] {2, 2, 2, 2, 2, 2, 2, 1};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		Integer[] expectedArray = new Integer[] {1};
		ArrayList<Integer>expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN05
	
	@Test
	public void testRemoveEvensN06() {
		Integer[] inputArray = new Integer[] {2, 2, 2, 2, 2, 2, 2};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		Integer[] expectedArray = new Integer[] {};
		ArrayList<Integer>expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN06
	
	@Test
	public void testRemoveEvensN07() {
		Integer[] inputArray = new Integer[] {2, 2, 2, 2, 2, 2, 2, 1, 3, 5, 7};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		Integer[] expectedArray = new Integer[] {1, 3, 5, 7};
		ArrayList<Integer>expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN07
	
	@Test
	public void testRemoveEvensN08() {
		Integer[] inputArray = new Integer[] {1, 3, 5, 7, 2, 2, 2, 2, 2, 2, 2};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		Integer[] expectedArray = new Integer[] {1, 3, 5, 7};
		ArrayList<Integer>expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN08
	
	@Test
	public void testRemoveEvensN09() {
		Integer[] inputArray = new Integer[] {2, 2, 2, 1, 3, 5, 7, 2, 2, 2, 2};
		ArrayList<Integer>input = new ArrayList<Integer>(Arrays.asList(inputArray));
		MH08.removeEvens(input);
		Integer[] expectedArray = new Integer[] {1, 3, 5, 7};
		ArrayList<Integer>expected = new ArrayList<Integer>(Arrays.asList(expectedArray));
		assertEquals(expected, input);
	} // testRemoveEvensN09
	
}

