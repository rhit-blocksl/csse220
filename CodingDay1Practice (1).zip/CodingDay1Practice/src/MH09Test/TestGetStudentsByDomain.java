package MH09Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.junit.Test;

import MH09.MH09;

public class TestGetStudentsByDomain {

	

	
	
	private boolean containsExactly (ArrayList<String> answer, ArrayList<String> actual) {
		return actual.containsAll(answer) && answer.containsAll(actual);
	} // containsExactly


	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	@Test
	public void testGetStudentsByDomain_MajorsOnly() {
		HashMap<String, String> usernameToMajorMap = new HashMap<>();
		usernameToMajorMap.put("Alice", "Computer Science");
		usernameToMajorMap.put("Bob", "Mathematics");
		usernameToMajorMap.put("Charlie", "English");
		
		HashMap<String, String> usernameToMinorMap = new HashMap<>();
		usernameToMinorMap.put("Alice", "Mathematics");
		usernameToMinorMap.put("Bob", "Computer Science");
		usernameToMinorMap.put("Charlie", "History");
		
		ArrayList<String> expected = new ArrayList<>();
		expected.add("Alice");
		expected.add("Bob");
		
		ArrayList<String> actual = MH09.getStudentsByDomain(usernameToMajorMap, usernameToMinorMap, "Computer Science");
		
		assertTrue( containsExactly(expected, actual) );
	}
	
	@Test
	public void testGetStudentsByDomain_MinorsOnly() {
		HashMap<String, String> usernameToMajorMap = new HashMap<>();
		usernameToMajorMap.put("Alice", "Computer Science");
		usernameToMajorMap.put("Bob", "Mathematics");
		usernameToMajorMap.put("Charlie", "English");
		
		HashMap<String, String> usernameToMinorMap = new HashMap<>();
		usernameToMinorMap.put("Alice", "Mathematics");
		usernameToMinorMap.put("Bob", "Computer Science");
		usernameToMinorMap.put("Charlie", "History");
		
		ArrayList<String> expected = new ArrayList<>();
		expected.add("Charlie");
		
		ArrayList<String> actual = MH09.getStudentsByDomain(usernameToMajorMap, usernameToMinorMap, "History");
		
		assertTrue( containsExactly(expected, actual) );
	}
	
	@Test
	public void testGetStudentsByDomain_MajorsAndMinors() {
		HashMap<String, String> usernameToMajorMap = new HashMap<>();
		usernameToMajorMap.put("Alice", "Computer Science");
		usernameToMajorMap.put("Bob", "Mathematics");
		usernameToMajorMap.put("Charlie", "English");
		
		HashMap<String, String> usernameToMinorMap = new HashMap<>();
		usernameToMinorMap.put("Alice", "Mathematics");
		usernameToMinorMap.put("Bob", "Computer Science");
		usernameToMinorMap.put("Charlie", "History");
		
		ArrayList<String> expected = new ArrayList<>();
		expected.add("Alice");
		expected.add("Bob");
		
		ArrayList<String> actual = MH09.getStudentsByDomain(usernameToMajorMap, usernameToMinorMap, "Mathematics");
		
		
		
		assertTrue( containsExactly(expected, actual) );
	}
	
	@Test
	public void testGetStudentsByDomain_EmptyMaps() {
		HashMap<String, String> usernameToMajorMap = new HashMap<>();
		HashMap<String, String> usernameToMinorMap = new HashMap<>();
		
		ArrayList<String> expected = new ArrayList<>();
		
		ArrayList<String> actual = MH09.getStudentsByDomain(usernameToMajorMap, usernameToMinorMap, "Computer Science");
		
		assertTrue( containsExactly(expected, actual) );
	}
	
	
	@Test
	public void testGetStudentsByDomain_NoMatch() {
		HashMap<String, String> usernameToMajorMap = new HashMap<>();
		usernameToMajorMap.put("Alice", "Computer Science");
		usernameToMajorMap.put("Bob", "Mathematics");
		usernameToMajorMap.put("Charlie", "English");
		
		HashMap<String, String> usernameToMinorMap = new HashMap<>();
		usernameToMinorMap.put("Alice", "Mathematics");
		usernameToMinorMap.put("Bob", "Computer Science");
		usernameToMinorMap.put("Charlie", "History");
		
		ArrayList<String> expected = new ArrayList<>();
		
		ArrayList<String> actual = MH09.getStudentsByDomain(usernameToMajorMap, usernameToMinorMap, "Chemistry");
		
		assertTrue( containsExactly(expected, actual) );
	}
	

	
	
	@Test
	public void testGetStudentsByDomain_SameMajorMinor() {
		HashMap<String, String> usernameToMajorMap = new HashMap<>();
		usernameToMajorMap.put("Alice", "Computer Science");
		usernameToMajorMap.put("Bob", "Mathematics");
		usernameToMajorMap.put("Charlie", "English");
		usernameToMajorMap.put("Eve", "Computer Science");
		usernameToMajorMap.put("Freda", "Undeclared");
		
		HashMap<String, String> usernameToMinorMap = new HashMap<>();
		usernameToMinorMap.put("Alice", "Mathematics");
		usernameToMinorMap.put("Bob", "Computer Science");
		usernameToMinorMap.put("Charlie", "History");
		usernameToMinorMap.put("Eve", "History");
		usernameToMinorMap.put("Freda", "Undeclared");
		
		ArrayList<String> expected = new ArrayList<>();
		expected.add("Freda");
		
		ArrayList<String> actual = MH09.getStudentsByDomain(usernameToMajorMap, usernameToMinorMap, "Undeclared");
		
		assertTrue( containsExactly(expected, actual) );
	}
	
	
}



