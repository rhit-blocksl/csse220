package MH09Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.junit.Test;
import MH09.MH09;


public class TestUpdatePhoneBook {
	
	@Test
	public void testUpdatePhoneBook() {
		HashMap<String, ArrayList<String>> phonebook = new HashMap<String, ArrayList<String>>();
		String[] namesToStart = {"John Smith", "Anne Jones", "Stacy Jones"};
		String[][] numbersToStart = {{"111-1111", "222-2222"},
									 {"333-3333"},
									 {"444-4444", "555-5555", "777-7777"}};
		for(int i = 0; i < namesToStart.length; i++) {
			phonebook.put(namesToStart[i], new ArrayList<String>(Arrays.asList(numbersToStart[i])));
		}
		
		String[] names = {"John Smith", "Alex Davies", "Anne Jones", "Anne Jones", "John Smith", 
							"Taylor Swift", "Taylor Swift", "Stacy Jones", "Stacy Jones", "Stacy Jones"};
		String[] newNumbers = {"888-8888", "999-9999", "000-0000", "123-1234", "987-9876", "121-2121", 
								"787-8787",	"444-4444", "555-5555", "030-3030"};
		
		HashMap<String, ArrayList<String>> expectedPhonebook = new HashMap<String, ArrayList<String>>();
		String[] expectedNames = {"John Smith", "Anne Jones", "Stacy Jones", "Alex Davies", "Taylor Swift"};
		String[][] expectedNumbers = {{"111-1111", "222-2222", "888-8888", "987-9876"},
				                      {"333-3333", "000-0000", "123-1234"},
				                      {"444-4444", "555-5555", "777-7777", "030-3030"},
				                      {"999-9999"},
				                      {"121-2121", "787-8787"}};
		
		for(int i = 0; i < expectedNames.length; i++) {
			expectedPhonebook.put(expectedNames[i], new ArrayList<String>(Arrays.asList(expectedNumbers[i])));
		}
		
		MH09.updatePhoneBook(phonebook, names, newNumbers);
		
		assertEquals(expectedPhonebook, phonebook);
		
		
		
		
		phonebook = new HashMap<String, ArrayList<String>>();
		namesToStart = new String[]{"A", "B", "C", "D", "E"};
		numbersToStart = new String[][]{{"1", "2"},
				 				        {"3"},
				 				        {"4"},
				 				        {"5", "6", "7"},
				 				        {"8", "9"}};
				 				        
		for(int i = 0; i < namesToStart.length; i++) {
			phonebook.put(namesToStart[i], new ArrayList<String>(Arrays.asList(numbersToStart[i])));
		}
		
		names = new String[] {"A", "A", "A", "B", "B", "C", "F", "F", "F", "G", "G", "H", "H", "H", "I"};
		newNumbers = new String[] {"1", "11", "111", "3", "33", "44", "0", "00", "000", "123", "321", "999", "999", "999", "1234567890"};
		
		expectedPhonebook = new HashMap<String, ArrayList<String>>();
		expectedNames = new String[] {"A", "B", "C", "D", "E", "F", "G", "H", "I"};
		expectedNumbers = new String[][] {{"1", "2", "11", "111"},
		        						  {"3", "33"},
		        						  {"4", "44"},
		        						  {"5", "6", "7"},
		        						  {"8", "9"},
		        						  {"0", "00", "000"},
		        						  {"123", "321"},
		        						  {"999"},
		        						  {"1234567890"}};
		for(int i = 0; i < expectedNames.length; i++) {
			expectedPhonebook.put(expectedNames[i], new ArrayList<String>(Arrays.asList(expectedNumbers[i])));
		}	
		
		MH09.updatePhoneBook(phonebook, names, newNumbers);
		
		assertEquals(expectedPhonebook, phonebook);
	}
	
}
