package MH09Test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import MH09.MH09;

public class TestHomecomingGameResult {

	// JUnit tests for homecomingGameResult
		private HashMap<String, String> footballMap;

		@Before
		public void setUp() {
			footballMap = new HashMap<>();
	        footballMap.put("2023","03-64");
	        footballMap.put("2022","14-48");
	        footballMap.put("2021","21-31");
	        footballMap.put("2019","29-28");
	        footballMap.put("2018","14-23");
	        footballMap.put("2010","14-14"); // Not a real game. Just a test for "tie"
	        
		}
	
		@Test
	    public void testHomecomingWin2023() {
			String result = MH09.homecomingGameResult(footballMap, "2023");
	        assertEquals("win", result);
		}
		
		@Test
	    public void testHomecomingWin2022() {
			String result = MH09.homecomingGameResult(footballMap, "2022");
	        assertEquals("win", result);
		}
	    
		@Test
	    public void testHomecomingWin2021() {
			String result = MH09.homecomingGameResult(footballMap, "2021");
	        assertEquals("win", result);
		}
	    
		@Test
	    public void testNoGame2021() {
	    	// lousy COVID
			String result = MH09.homecomingGameResult(footballMap, "2020");
	        assertEquals("missing data", result);
		}
	    
		@Test
	    public void testHomecomingLoss2019() {
			String result = MH09.homecomingGameResult(footballMap, "2019");
	        assertEquals("loss", result);
		}
		
		@Test
	    public void testHomecomingTie2010() {
			// Not a real game. Just a test for "tie"
			String result = MH09.homecomingGameResult(footballMap, "2010");
	        assertEquals("tie", result);
		}
		


}
