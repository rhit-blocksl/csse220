package MH08;


import java.util.*;
public class MH08 {

	/** See printed instructions for a description of this method. */
	public static void removeEvens(ArrayList<Integer> list) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static int[] findPair(int target, int[] array) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static int[] interleaveArrays(int[] evenIndexes, int[] oddIndexes) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static String generateString(int[] numbers, String[] inputStrs) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}
}
