package MH09;


import java.util.*;
public class MH09 {

	/** See printed instructions for a description of this method. */
	public static String homecomingGameResult(HashMap<String, String> gameHistoryMap, String year) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static ArrayList<String> getStudentsByDomain(HashMap<String, String> usernameToMajorMap,
				HashMap<String, String> usernameToMinorMap, String domain) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static String findOneAnimal(HashMap<String, String> animialToColorMap, String colorToFind) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static void updatePhoneBook(HashMap<String, ArrayList<String>> phonebook, String[] names, String[] newNumbers) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}
}
